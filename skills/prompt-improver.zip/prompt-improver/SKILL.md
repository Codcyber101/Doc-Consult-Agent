---
name: prompt-improver
description: This skill helps users refine and optimize their prompts for coding agents to ensure higher quality, more accurate, and context-aware responses. It provides strategies, checklists, and templates for common coding tasks.
---

# Prompt Improver

## Overview
The **Prompt Improver** skill assists users in crafting high-efficacy prompts for coding agents. By analyzing the user's initial input and applying established prompt engineering patterns, this skill ensures that the resulting instructions to the agent are clear, context-rich, and structured for success.

## Workflow

To improve a prompt, follow this systematic process:

### 1. Analyze the Input
Read the user's draft prompt and identify:
- **Core Intent:** What is the user trying to achieve? (e.g., fix a bug, build a feature, refactor code).
- **Missing Elements:** Check against the **Prompt Quality Checklist** (`references/checklist.md`). Common missing items include:
    - Tech stack details.
    - Explicit constraints.
    - Expected output format.
    - Example inputs/outputs (Few-Shot).

### 2. Select a Strategy
Based on the intent, choose the appropriate pattern from `references/patterns.md`:
- **New Feature:** Use the **Feature Implementation Prompt Template**.
- **Bug Fix:** Use the **Bug Fix Prompt Template**.
- **Complex Logic:** Apply **Chain of Thought (CoT)**.
- **Strict Requirements:** Apply **Constraint Enforcement**.

### 3. Draft the Improvement
Rewrite the user's prompt.
- **Expand Context:** Add missing details (ask the user if unknown).
- **Structure:** Use clear headings and bullet points.
- **Refine Tone:** Ensure a persona is defined (e.g., "Act as a Senior Engineer").
- **Incorporate Templates:** Refer to `assets/templates/` for structured starting points if the user's prompt is too vague.

### 4. Explain and Educate
Present the improved prompt to the user, followed by a brief explanation:
- Highlight *what* was added (e.g., "Added a 'Constraints' section...").
- Explain *why* it helps (e.g., "...to prevent the agent from using unauthorized libraries.").

## Usage Guidelines

### Using the Checklist
Refer to `references/checklist.md` to audit any prompt. If a prompt fails multiple checks, prioritize fixing "Context & Goal" and "Technical Specifics" first.

### Using Templates
- **Bug Reports:** If the user says "Fix this error," use `assets/templates/bug_report.md` to structure the request.
- **Feature Requests:** If the user says "I need a login page," use `assets/templates/feature_request.md`.

### Interactive Mode
If the user's input is extremely minimal (e.g., "Write code for a snake game"), do not just guess. Ask clarifying questions based on the checklist:
> "To give you the best prompt, I need a bit more detail:
> 1. What language/framework should I use? (Python/Pygame? JavaScript/Canvas?)
> 2. Do you need a specific visual style?
> 3. Should it run in the terminal or a browser?"

## Example Interaction

**User:** "Fix the database error."

**Agent (Skill Active):**
> "I can help you write a better prompt to get that fixed. Here is an improved version based on the **Bug Fix Pattern**:
>
> **Improved Prompt:**
> 'Act as a Backend Engineer. I am seeing a database error in my Python/Django application.
> **Context:** The error occurs when a user tries to save a profile with a duplicate email.
> **Error Log:** [Paste the exact traceback here]
> **Code:** [Paste the User model code here]
> **Goal:** Fix the handling of `IntegrityError` to return a user-friendly 400 Bad Request response instead of a 500 error.'
>
> **Why this is better:** It specifies the role, tech stack, the exact trigger, and the desired outcome (400 vs 500 error), which reduces the chance of a generic or incorrect solution."